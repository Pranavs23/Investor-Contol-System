<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<table width="1021" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="202" height="33">&nbsp;</td>
    <td width="507">&nbsp;</td>
    <td width="312">&nbsp;</td>
  </tr>
  <tr>
    <td height="321">&nbsp;</td>
    <td valign="top"><div align="center">
      <p>LOGIN</p>
      <form name="form1" method="post" action="">
        
        <table width="220" border="1">
          <tr>
            <td width="113">UserID</td>
            <td width="91">&nbsp;</td>
          </tr>
          <tr>
            <td>Password</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td colspan="2"><div align="center">
		<?php
		$s1=$_POST['t1'];
		$s2=$_POST['t2'];
	  session_start();
	  include("connection.php");
	$s=mysql_query("select * from login where userid='$s1' and password='$s2'");
	if(mysql_num_rows($s)==0)
	  echo "<b>invalid userid or password";
	  else
	  {
	   if($s1=="admin")
	 	   header('location:adminprocess.php');
		   else
		   {
		   $x=substr($s1,0,1);
		   if($x=="i")
		   {
		    $s=mysql_query("select * from invapproval where invid='$s1'");
		    $appstatus="";
		    if(mysql_num_rows($s)==0)
		      echo "<b>Please wait for the approval";
			 else
			 {
			 $row=mysql_fetch_array($s);
			 $appstatus=$row[1];
			 if($appstatus=="n")
			   echo "<b>Your registration rejected";
			   else
			   {
			   $_SESSION["invid"]=$s1;
			   header('location:invprocess.php');
			   }
			 
			 
			 } 
		   
		   }
		   else   // for company
		   {	//*****
		   
		   
		   
		   if($x=="c")
		   {
		    $s=mysql_query("select * from cmpapproval where cmpid='$s1'");
		    $appstatus="";
		    if(mysql_num_rows($s)==0)
		      echo "<b>Please wait for the approval";
			 else
			 {
			 $row=mysql_fetch_array($s);
			 $appstatus=$row[1];
			 if($appstatus=="n")
			   echo "<b>Your registration rejected";
			   else
			   {
			   $_SESSION["cmpid"]=$s1;
			   header('location:cmpprocess.php');
		     }
		   
		   }
		   
		   }
		   
		   }    //*****
		   
		   }
	  }
	  
	  ?>
            </div></td>
            </tr>
        </table>
      </form>
      <p>&nbsp;</p>
    </div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="928">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>