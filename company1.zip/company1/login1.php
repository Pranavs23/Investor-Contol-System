<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php include("p1.php");  ?>
<table width="1067" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="202" height="33">&nbsp;</td>
    <td width="507">&nbsp;</td>
    <td width="358">&nbsp;</td>
  </tr>
  <tr>
    <td height="182">&nbsp;</td>
    <td valign="top"><div align="center">
        <p> LOGIN</p>
        <form name="form1" method="post" action="login2.php">
          <table width="220" border="0">
            <tr>
              <td width="113">UserID</td>
              <td width="91"><input name="t1" type="text" id="t1"></td>
            </tr>
            <tr>
              <td>Password</td>
              <td><input name="t2" type="text" id="t2"></td>
            </tr>
            <tr>
              <td colspan="2"><div align="center">
                <input type="submit" name="Submit" value="Sign in">
              </div></td>
            </tr>
          </table>
        </form>
        <p>&nbsp;</p>
    </div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="145">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
